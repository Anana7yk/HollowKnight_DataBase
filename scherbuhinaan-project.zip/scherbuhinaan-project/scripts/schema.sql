CREATE TABLE IF NOT EXISTS Players (
                         Player_ID SERIAL PRIMARY KEY,
                         Name VARCHAR(200) NOT NULL,
                         Max_Health INT NOT NULL CHECK(Max_Health >= 5),
                         Country VARCHAR(200) NOT NULL
);

CREATE TABLE IF NOT EXISTS Locations (
                           Location_ID SERIAL PRIMARY KEY,
                           Name VARCHAR(200) NOT NULL,
                           Region VARCHAR(200) NOT NULL,
                           Parent_Location_ID INT,
                           Description VARCHAR(200),
                           FOREIGN KEY (Parent_Location_ID) REFERENCES Locations(Location_ID)
);

CREATE TABLE IF NOT EXISTS Bosses (
                        Boss_ID SERIAL PRIMARY KEY,
                        Name VARCHAR(200) NOT NULL,
                        HP INT NOT NULL CHECK(HP >= 0),
                        Damage INT NOT NULL CHECK(Damage >= 0),
                        Location_ID INT NOT NULL,
                        FOREIGN KEY (Location_ID) REFERENCES Locations(Location_ID)
);

CREATE TABLE IF NOT EXISTS Enemies (
                         Enemy_ID SERIAL PRIMARY KEY,
                         Name VARCHAR(200) NOT NULL,
                         HP INT NOT NULL CHECK(HP >= 0),
                         Damage INT NOT NULL CHECK(Damage >= 0),
                         Location_ID INT NOT NULL,
                         FOREIGN KEY (Location_ID) REFERENCES Locations(Location_ID)
);

CREATE TABLE IF NOT EXISTS NPCs (
                      NPC_ID SERIAL PRIMARY KEY,
                      Name VARCHAR(200) NOT NULL,
                      Role VARCHAR(200) NOT NULL,
                      Location_ID INT NOT NULL,
                      FOREIGN KEY (Location_ID) REFERENCES Locations(Location_ID)
);


CREATE TABLE IF NOT EXISTS Location_Connections (
                                      Connection_ID SERIAL PRIMARY KEY,
                                      Location1_ID INT NOT NULL,
                                      Location2_ID INT NOT NULL,
                                      FOREIGN KEY (Location1_ID) REFERENCES Locations(Location_ID),
                                      FOREIGN KEY (Location2_ID) REFERENCES Locations(Location_ID)
);

CREATE TABLE IF NOT EXISTS Items (
                       Item_ID SERIAL PRIMARY KEY,
                       Name VARCHAR(200) NOT NULL,
                       Type VARCHAR(100) NOT NULL,
                       Effect TEXT
);

CREATE TABLE IF NOT EXISTS Item_Drop (
                           Drop_ID SERIAL PRIMARY KEY,
                           Item_ID INT NOT NULL,
                           Enemy_ID INT NULL,
                           Boss_ID INT NULL,
                           NPC_ID INT NULL,
                           Location_ID INT NULL,
                           FOREIGN KEY (Item_ID) REFERENCES Items(Item_ID),
                           FOREIGN KEY (Enemy_ID) REFERENCES Enemies(Enemy_ID),
                           FOREIGN KEY (Boss_ID) REFERENCES Bosses(Boss_ID),
                           FOREIGN KEY (NPC_ID) REFERENCES NPCs(NPC_ID),
                           FOREIGN KEY (Location_ID) REFERENCES Locations(Location_ID)
);

CREATE TABLE IF NOT EXISTS Charms (
                        Charm_ID SERIAL PRIMARY KEY,
                        Item_ID INT UNIQUE NOT NULL,
                        Effect VARCHAR(100) NOT NULL,
                        Cost INT NOT NULL CHECK(Cost >= 0),
                        FOREIGN KEY (Item_ID) REFERENCES Items(Item_ID)
);

CREATE TABLE IF NOT EXISTS Highscore (
                           Highscore_ID SERIAL PRIMARY KEY,
                           Player_ID INT NOT NULL,
                           Boss_ID INT NOT NULL,
                           Completion_Time TIME NOT NULL CHECK(Completion_Time >= '00:00:00'),
                           Score INT NOT NULL,
                           FOREIGN KEY (Player_ID) REFERENCES Players(Player_ID),
                           FOREIGN KEY (Boss_ID) REFERENCES Bosses(Boss_ID)
);

CREATE TABLE IF NOT EXISTS Highscore_History (
                                   History_ID SERIAL PRIMARY KEY,
                                   Highscore_ID INT NOT NULL,
                                   Previous_Score INT,
                                   Previous_Time TIME,
                                   Change_Date TIMESTAMP NOT NULL,
                                   FOREIGN KEY (Highscore_ID) REFERENCES Highscore(Highscore_ID)
);