SELECT l.Name AS Location, COUNT(b.Boss_ID) AS Boss_Count
FROM Locations l
         LEFT JOIN Bosses b ON l.Location_ID = b.Location_ID
GROUP BY l.Name
ORDER BY Boss_Count DESC;

SELECT Name, Max_Health
FROM Players
WHERE Max_Health > (SELECT AVG(Max_Health) FROM Players)
ORDER BY Max_Health DESC;

SELECT p.Name, MAX(h.Score) AS Best_Score
FROM Players p
         JOIN Highscore h ON p.Player_ID = h.Player_ID
GROUP BY p.Name
ORDER BY Best_Score DESC
LIMIT 5;

WITH AvgCost AS (
    SELECT AVG(Cost) AS Average
    FROM Charms
)
SELECT c.Effect, c.Cost
FROM Charms c, AvgCost
WHERE c.Cost > AvgCost.Average
ORDER BY c.Cost DESC;

SELECT i.Name
FROM Items i
WHERE EXISTS (
    SELECT 1 FROM Item_Drop d
    WHERE d.Item_ID = i.Item_ID AND d.Boss_ID IS NOT NULL
) AND EXISTS (
    SELECT 1 FROM Item_Drop d
    WHERE d.Item_ID = i.Item_ID AND d.Enemy_ID IS NOT NULL
);

SELECT n.Name, COUNT(d.Drop_ID) AS Items_Given
FROM NPCs n
         LEFT JOIN Item_Drop d ON n.NPC_ID = d.NPC_ID
GROUP BY n.Name
HAVING COUNT(d.Drop_ID) > 0
ORDER BY Items_Given DESC;

SELECT
    p.Name,
    h.Completion_Time,
    RANK() OVER (ORDER BY h.Completion_Time) AS Rank
FROM Highscore h
         JOIN Players p ON h.Player_ID = p.Player_ID;

SELECT l.Name, COUNT(c.Connection_ID) AS Connections
FROM Locations l
         JOIN Location_Connections c
              ON l.Location_ID = c.Location1_ID OR l.Location_ID = c.Location2_ID
GROUP BY l.Name
HAVING COUNT(c.Connection_ID) > 3;

SELECT
    b1.Name AS Boss,
    h1.Completion_Time AS Time_Player1,
    h2.Completion_Time AS Time_Player2
FROM Highscore h1
         JOIN Highscore h2 ON h1.Boss_ID = h2.Boss_ID AND h1.Player_ID <> h2.Player_ID
         JOIN Bosses b1 ON h1.Boss_ID = b1.Boss_ID
LIMIT 10;

SELECT
    p.Name,
    h.Change_Date,
    h.Previous_Score,
    LAG(h.Previous_Score) OVER (PARTITION BY p.Player_ID ORDER BY h.Change_Date) AS Previous_Score_Lag
FROM Highscore_History h
         JOIN Players p ON h.Highscore_ID = p.Player_ID;